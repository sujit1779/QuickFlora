﻿Imports System.Data
Imports System.Data.SqlClient


Partial Class RecipeDetails
    Inherits System.Web.UI.Page

    Dim CompanyID As String = ""
    Dim DivisionID As String = ""
    Dim DepartmentID As String = ""

    Public imgW As Integer = 49
    Public imgH As Integer = 34

    Dim obj As New clsInventoryAssembly

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        CompanyID = Session("CompanyID")
        DivisionID = Session("DivisionID")
        DepartmentID = Session("DepartmentID")

        txtLaborRate.Attributes.Add("onblur", "onblurFunctiontxtLaborRate(this)")
        txtLaborRate.Attributes.Add("onfocus", "myFocusFunction(this)")

        txtAssmeblyTime.Attributes.Add("onblur", "onblurFunctiontxtLaborRate(this)")
        txtAssmeblyTime.Attributes.Add("onfocus", "myFocusFunction(this)")
        'txtProduct.Attributes.Add("onfocus", "myFocusFunction(this)")

        txtMargin.Attributes.Add("onblur", "onblurFunctiontxtMargin(this)")
        txtMargin.Attributes.Add("onfocus", "myFocusFunction(this)")

        Dim AssemblyID As String = ""
        dvsave.Visible = False

        If Not Page.IsPostBack Then
            If Request.QueryString("ItemID") <> String.Empty Then
                'txtItemID.Text = Request.QueryString("ItemID")
                'txtItemID.Enabled = False

                'Dim dt As New DataTable
                'dt = obj.GetInventoryAssemblyListByItem(CompanyID, DivisionID, DepartmentID, txtItemID.Text)

                'If dt.Rows.Count > 0 Then
                '    AssemblyID = dt.Rows(0)("AssemblyID")
                'Else
                '    txtAssembly.Text = txtItemID.Text
                'End If

                'If AssemblyID <> "" Then
                '    GetInventoryAssembly(CompanyID, DivisionID, DepartmentID, AssemblyID)
                '    btnsave.Text = "Update Recipe"
                'End If

            End If



            If Request.QueryString("AssemblyID") <> String.Empty Then
                AssemblyID = Request.QueryString("AssemblyID")
                GetInventoryAssembly(CompanyID, DivisionID, DepartmentID, AssemblyID)
                btnsave.Text = "Update Recipe"
            Else
                SetOrderProductEmptyData()
                'AssemblyID = GenerateRandomAssemblyID()
                ' drpPriceType.AutoPostBack = False
            End If

        End If

    End Sub


    Public Sub SetOrderProductEmptyData()
        Dim dt As New DataTable()
        dt.Columns.Add(New DataColumn("RowID"))
        dt.Columns.Add(New DataColumn("AssemblyID"))
        dt.Columns.Add(New DataColumn("ItemID"))
        dt.Columns.Add(New DataColumn("ItemName"))
        dt.Columns.Add(New DataColumn("Qty"))
        dt.Columns.Add(New DataColumn("UnitPrice"))
        dt.Columns.Add(New DataColumn("TotalPrice"))
         
        Dim dr As DataRow
        dr = dt.NewRow()

        dr("RowID") = 0
        dr("AssemblyID") = 1
        dr("ItemID") = String.Empty
        dr("ItemName") = String.Empty
        dr("Qty") = String.Empty
        dr("UnitPrice") = String.Empty
        dr("TotalPrice") = String.Empty 
        dt.Rows.Add(dr)

        '//dr = dt.NewRow();

        OrderHeaderGrid.DataSource = dt
        OrderHeaderGrid.DataBind()

    End Sub



    Private Sub GetInventoryAssembly(ByVal CompanyID As String, ByVal DivisionID As String, ByVal DepartmentID As String, _
                                   ByVal AssemblyID As String, Optional ByVal PriceType As String = "")



        Dim dt As New DataTable
        dt = obj.GetInventoryAssmeblyList(CompanyID, DivisionID, DepartmentID, AssemblyID, "Normal")

        If dt.Rows.Count > 0 Then
            Dim row As DataRow = dt.Rows(0)
            txtAssembly.Text = row("AssemblyID")
            txtAssembly.Enabled = False
            txtItemID.Text = row("ItemID")
            txtNumberOfItemsInAssembly.Text = row("NumberOfItemsInAssembly")
            'txtCurrencyID.Text = IIf(IsDBNull(row("CurrencyID")), "USD", row("CurrencyID"))
            'txtCurrencyExchangeRate.Text = IIf(IsDBNull(row("CurrencyExchangeRate")), "1", row("CurrencyExchangeRate"))

            txtTotalCost.Text = String.Format("{0:N2}", row("TotalCost"))
            'txtTotalRetail.Text = String.Format("{0:N2}", row("TotalRetail"))
            txtMargin.Text = String.Format("{0:N2}", row("Margin"))
            txtAssmeblyTime.Text = String.Format("{0:N2}", row("AssemblyTime"))
            txtLaborCost.Text = String.Format("{0:N2}", row("LaborCost"))
            txtLaborRate.Text = String.Format("{0:N2}", row("LaborRate"))

            txtAssemblyInstruction.Text = IIf(IsDBNull(row("Instruction")), "", row("Instruction"))
            txtAssemblyDescription.Text = IIf(IsDBNull(row("Description")), "", row("Description"))

            'drpCOGSAccount.SelectedValue = IIf(IsDBNull(row("GLAccount")), "", row("GLAccount"))
            'drpPriceType.SelectedValue = IIf(IsDBNull(row("PriceType")), "", row("PriceType"))

            GetInventoryAssemblyItems()

        Else

            txtNumberOfItemsInAssembly.Text = ""
            txtTotalCost.Text = ""
            txtMargin.Text = ""
            txtAssmeblyTime.Text = ""
            txtLaborCost.Text = ""
            txtLaborRate.Text = ""
            txtAssemblyInstruction.Text = ""

            btnSave.Text = "Save Recipe"
            GetInventoryAssemblyItems()

        End If

    End Sub

    Private Function GenerateRandomAssemblyID() As String

        Dim legalChars As String = "1234567890"
        Dim str As New StringBuilder
        Dim ch As Char
        Dim random As New Random

        For i As Integer = 0 To 9
            ch = legalChars(random.Next(0, legalChars.Length))
            str.Append(ch)
        Next

        txtAssembly.Text = str.ToString

        Return str.ToString

    End Function

    '  SELECT [CompanyID]
    '    ,[DivisionID]
    '    ,[DepartmentID]
    '    ,[AssemblyID]
    '    ,[ItemID]
    '    ,[Qty]
    '    ,[UnitPrice]
    '    ,[TotalPrice]
    '    ,[CreatedDate]
    '    ,[PriceType]
    '    ,[RowID]
    '    ,[RetailCost]
    '    ,[TotalRetailCost]
    'FROM [Enterprise].[dbo].[InventoryAssemblyDetail]

    Private Sub GetInventoryAssemblyItems()

        Dim dtItemsInAssembly As New DataTable
        dtItemsInAssembly = obj.GetInventoryAssmeblyDetailList(CompanyID, DivisionID, DepartmentID, txtAssembly.Text.Trim, "Normal")

        If dtItemsInAssembly.Rows.Count > 0 Then
            'LOAD ITEMS LIST IN HERE
            OrderHeaderGrid.DataSource = dtItemsInAssembly
            OrderHeaderGrid.DataBind()
            OrderHeaderGrid.Visible = True
        Else
            SetOrderProductEmptyData()
            'OrderHeaderGrid.Visible = False
        End If

        Dim Total As Decimal = 0

        For Each row As DataRow In dtItemsInAssembly.Rows
            Total = Total + Convert.ToDouble(row("TotalPrice"))
        Next

        txtSubTotal.Text = String.Format("{0:N2}", Total)

        Dim laborCost As Double = Convert.ToDouble(IIf(txtLaborCost.Text.Trim = "", 0, txtLaborCost.Text.Trim))

        txtTotalCost.Text = String.Format("{0:N2}", Total + laborCost)

        Dim cost As Double = Convert.ToDouble(IIf(txtTotalCost.Text.Trim = "", 0, txtTotalCost.Text.Trim))

        Dim margin As Double = Convert.ToDouble(IIf(txtMargin.Text.Trim = "", 0, txtMargin.Text.Trim))
        txtTotalRetail.Text = String.Format("{0:N2}", cost + (margin * cost * 0.01))

        If margin = 0 Then
            txtMarginDollar.Text = 0.0
        Else
            txtMarginDollar.Text = String.Format("{0:N2}", (margin * cost * 0.01))
        End If

        txtNumberOfItemsInAssembly.Text = dtItemsInAssembly.Rows.Count.ToString

    End Sub



    Private Sub OrderHeaderGrid_RowDataBound(ByVal sender As Object, ByVal e As GridViewRowEventArgs) Handles OrderHeaderGrid.RowDataBound
        'Exit Sub
        Dim txtInLineNumber As New TextBox
        'Response.Write(e.Row.RowType)
        If e.Row.RowType = DataControlRowType.DataRow Then
            txtInLineNumber = e.Row.FindControl("txtInLineNumber")
            If txtInLineNumber.Text = "0" Then
                e.Row.Visible = False
            End If
            e.Row.Attributes("id") = txtInLineNumber.Text

            ' InventoryAssemblyDetail.ItemID,InventoryAssemblyDetail.Qty,InventoryAssemblyDetail.UnitPrice,InventoryAssemblyDetail.TotalPrice  

            Dim txtProduct As TextBox = e.Row.FindControl("txtProduct")

            Dim txtQ_ORD As TextBox = e.Row.FindControl("txtQ_ORD")
            Dim txtCOST As TextBox = e.Row.FindControl("txtCOST")
            Dim txtExt_COSt As TextBox = e.Row.FindControl("txtExt_COSt")

            txtProduct.Attributes.Add("autocomplete", "off")
            txtQ_ORD.Attributes.Add("autocomplete", "off")
            txtCOST.Attributes.Add("autocomplete", "off")
            txtExt_COSt.Attributes.Add("autocomplete", "off")

            txtProduct.Attributes.Add("onfocus", "myFocusFunction(this)")
            txtProduct.Attributes.Add("onblur", "Saveitem(this,'" & txtInLineNumber.Text & "','ItemID','" & txtProduct.Text & "')")

            txtProduct.Attributes.Add("placeholder", "SEARCH Item")
            txtProduct.Attributes.Add("onKeyUp", "SendQuery2(this.value,this,'" & txtInLineNumber.Text & "','','" & txtCOST.ClientID & "','')")

            txtQ_ORD.Attributes.Add("onfocus", "myFocusFunction(this)")
            txtQ_ORD.Attributes.Add("onblur", "myFocusFunctiontotal('" & txtExt_COSt.ClientID & "','" & txtInLineNumber.Text & "','" & txtQ_ORD.ClientID & "','','" & txtCOST.ClientID & "')")

            txtCOST.Attributes.Add("onfocus", "myFocusFunction(this)")
            txtCOST.Attributes.Add("onblur", "myFocusFunctiontotal('" & txtExt_COSt.ClientID & "','" & txtInLineNumber.Text & "','" & txtQ_ORD.ClientID & "','','" & txtCOST.ClientID & "')")


        End If


    End Sub

    Public Function CheckAssemblyIDData() As Boolean
        Dim constr As String = ConfigurationManager.AppSettings("ConnectionString")
        Dim connec As New SqlConnection(constr)
        Dim ssql As String = ""
        Dim dt As New DataTable()
        ssql = "SELECT AssemblyID FROM [InventoryAssemblies] where  AssemblyID = @AssemblyID and CompanyID=@f0 and DivisionID=@f1 and DepartmentID=@f2 "
        Dim da As New SqlDataAdapter
        Dim com As SqlCommand
        com = New SqlCommand(ssql, connec)
        Try
            com.Parameters.Add(New SqlParameter("@f0", SqlDbType.NVarChar, 36)).Value = Me.CompanyID
            com.Parameters.Add(New SqlParameter("@f1", SqlDbType.NVarChar, 36)).Value = Me.DepartmentID
            com.Parameters.Add(New SqlParameter("@f2", SqlDbType.NVarChar, 36)).Value = Me.DivisionID
            com.Parameters.Add(New SqlParameter("@AssemblyID", SqlDbType.NVarChar, 36)).Value = txtAssembly.Text
            da.SelectCommand = com
            da.Fill(dt)


            If dt.Rows.Count = 0 Then
                Return True
            End If

        Catch ex As Exception

        End Try

        Return False
    End Function

    Public Function saveall() As Boolean
        Dim constr As String = ConfigurationManager.AppSettings("ConnectionString")

        Dim rs As SqlDataReader
        Dim OrderNo As String = ""

        Dim PopOrderNo As New DAL.CustomOrder()
        If IsNumeric(txtAssembly.Text.Trim) = False Then
            rs = PopOrderNo.GetNextOrdNumber(CompanyID, DepartmentID, DivisionID, "NextRecipeNumber")
            While rs.Read()
                OrderNo = rs("NextNumberValue")
            End While
            rs.Close()
            txtAssembly.Text = OrderNo
        Else
            OrderNo = txtAssembly.Text
        End If

        'txtlastchanged.Text = Date.Now
        'txtlastchangedby.Text = EmployeeID


        Dim connec As New SqlConnection(constr)
        Dim qry As String

       
        Dim Output As Boolean = False

        Dim AssemblyID As String = txtAssembly.Text.Trim
        Dim ItemID As String = txtItemID.Text.Trim
        Dim NumberOfItemsInAssembly As String = txtNumberOfItemsInAssembly.Text

        Dim CurrencyID As String = "$" ' txtCurrencyID.Text
        Dim CurrencyExchangeRate As String = "1" 'txtCurrencyExchangeRate.Text
        Dim TotalCost As String = txtTotalCost.Text
        Dim TotalRetail As String = txtTotalRetail.Text

        Dim Margin As String = txtMargin.Text
        Dim AssemblyTime As String = txtAssmeblyTime.Text
        Dim LaborRate As String = txtLaborRate.Text
        Dim LaborCost As String = txtLaborCost.Text
        Dim Instruction As String = txtAssemblyInstruction.Text
        Dim Description As String = txtAssemblyDescription.Text
        Dim GLAccount As String = "" 'drpCOGSAccount.SelectedValue
        Dim PriceType As String = "Normal" 'drpPriceType.SelectedValue

        Dim ErrorMessage As String = ""
        If CheckAssemblyIDData() Then
            Output = obj.InsertInventoryAssembly(CompanyID, DivisionID, DepartmentID, AssemblyID, ItemID, NumberOfItemsInAssembly, _
                                            CurrencyID, CurrencyExchangeRate, TotalCost, TotalRetail, Margin, AssemblyTime, LaborRate, LaborCost, _
                                            Instruction, Description, GLAccount, PriceType, ErrorMessage)
        Else
            Output = obj.UpdateInventoryAssembly(CompanyID, DivisionID, DepartmentID, AssemblyID, ItemID, NumberOfItemsInAssembly, _
                                            CurrencyID, CurrencyExchangeRate, TotalCost, TotalRetail, Margin, AssemblyTime, LaborRate, LaborCost, _
                                            Instruction, Description, GLAccount, PriceType, ErrorMessage)
        End If


        If Output Then
            '   Response.Redirect("EventInventoryAssemblyList.aspx")
            lblsave.Text = "Recipe <strong>#" & AssemblyID & "</strong> saved Successfully "
            dvsave.Visible = True
        Else
            lblsave.Visible = True
            lblsave.Text = ErrorMessage
            dvsave.Visible = True
        End If

        

        Return True
    End Function

    Protected Sub btnaddnew_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnaddnew.Click

        saveall()

        Dim AssemblyID As String = txtAssembly.Text.Trim
        Dim ErrorMessage As String = ""
        If obj.InsertInventoryAssmeblyItems(CompanyID, DivisionID, DepartmentID, txtAssembly.Text.Trim, "", 0, "0.00", "0.00", "Normal", ErrorMessage) Then
            GetInventoryAssemblyItems()
        Else
            lblsave.Visible = True
            lblsave.Text = ErrorMessage
            dvsave.Visible = True
        End If
       

    End Sub

    Protected Sub btnsavechanges_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnsavechanges.Click
        saveall()

    End Sub

    Protected Sub btnsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnsave.Click
        saveall()
        Response.Redirect("EventInventoryAssemblyList.aspx")
    End Sub
End Class
