﻿Option Strict Off

Imports EnterpriseASPClient.Core
'Imports EnterpriseClient.Core
Imports System.Data
Imports System.Data.SqlClient

Partial Class InventoryTransferLists
    Inherits System.Web.UI.Page

    Public CompanyID As String = ""
    Public DivisionID As String = ""
    Public DepartmentID As String = ""

    Dim SortDirection As String

    Dim obj As New clsInventoryTransfer


    Public Function FillLocationName(ByVal LocationID As String) As String
        Dim constr As String = ConfigurationManager.AppSettings("ConnectionString")
        Dim connec As New SqlConnection(constr)
        Dim ssql As String = ""
        Dim LocationName As String = ""
        Dim dt As New DataTable()
        ssql = "SELECT LocationName FROM [Order_Location] where  LocationID <> 'Wholesale' and CompanyID=@f0 and DivisionID=@f1 and DepartmentID=@f2 and LocationID=@LocationID"
        Dim da As New SqlDataAdapter
        Dim com As SqlCommand
        com = New SqlCommand(ssql, connec)
        Try
            com.Parameters.Add(New SqlParameter("@f0", SqlDbType.NVarChar, 36)).Value = Me.CompanyID
            com.Parameters.Add(New SqlParameter("@f1", SqlDbType.NVarChar, 36)).Value = Me.DepartmentID
            com.Parameters.Add(New SqlParameter("@f2", SqlDbType.NVarChar, 36)).Value = Me.DivisionID
            com.Parameters.Add(New SqlParameter("@LocationID", SqlDbType.NVarChar, 36)).Value = LocationID

            da.SelectCommand = com
            da.Fill(dt)


            If dt.Rows.Count <> 0 Then
                Try
                    LocationName = dt.Rows(0)(0)
                Catch ex As Exception

                End Try
            End If

            Return LocationName
        Catch ex As Exception
            Dim msg As String
            msg = ex.Message
            HttpContext.Current.Response.Write(msg)
            Return LocationName
        End Try
        Return LocationName
    End Function

    Public EmployeeID As String = ""
    Dim rs As SqlDataReader

    Public Function PopulateEmployees(ByVal CompanyID As String, ByVal DepartmentID As String, ByVal DivisionID As String, ByVal MO As String) As SqlDataReader

        Dim ConString As New SqlConnection(ConfigurationManager.AppSettings("ConnectionString"))
        ConString.Open()
        Dim myCommand As New SqlCommand("PopulateEmployeesByAccess", ConString)
        myCommand.CommandType = Data.CommandType.StoredProcedure

        Dim parameterCompanyID As New SqlParameter("@CompanyID", Data.SqlDbType.NVarChar, 36)
        parameterCompanyID.Value = CompanyID
        myCommand.Parameters.Add(parameterCompanyID)

        Dim parameterDepartmentID As New SqlParameter("@DepartmentID", Data.SqlDbType.NVarChar, 36)
        parameterDepartmentID.Value = DepartmentID
        myCommand.Parameters.Add(parameterDepartmentID)

        Dim parameterDivisionID As New SqlParameter("@DivisionID", Data.SqlDbType.NVarChar, 36)
        parameterDivisionID.Value = DivisionID
        myCommand.Parameters.Add(parameterDivisionID)

        Dim pModule As New SqlParameter("@Module", Data.SqlDbType.NVarChar, 36)
        pModule.Value = MO
        myCommand.Parameters.Add(pModule)

        Dim rs As SqlDataReader
        rs = myCommand.ExecuteReader(CommandBehavior.CloseConnection)
        Return rs



    End Function



    Public Function getEditVisible() As Boolean
        EmployeeID = Session("EmployeeID")

        rs = PopulateEmployees(CompanyID, DepartmentID, DivisionID, "MTEDIT")

        Dim securitycheck As Boolean = False

        While (rs.Read())

            If rs("EmployeeID").ToString() = EmployeeID Then
                securitycheck = True
                Exit While
            End If

        End While
        rs.Close()

       

        If securitycheck Then
            Return True
        Else
            Return False
        End If
    End Function

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim SessionKey As Hashtable = CType(Session("SessionKey"), Hashtable)
        CompanyID = CType(SessionKey("CompanyID"), String)
        DivisionID = CType(SessionKey("DivisionID"), String)
        DepartmentID = CType(SessionKey("DepartmentID"), String)

        EmployeeID = Session("EmployeeID")

        rs = PopulateEmployees(CompanyID, DepartmentID, DivisionID, "MT")

        Dim securitycheck As Boolean = False

        While (rs.Read())

            If rs("EmployeeID").ToString() = EmployeeID Then
                securitycheck = True
                Exit While
            End If

        End While
        rs.Close()

        If securitycheck = False Then
            Response.Redirect("SecurityAcessPermission.aspx?MOD=MT")
        End If

        txtcustomersearch.Attributes.Add("placeholder", "SEARCH")
        txtcustomersearch.Attributes.Add("onKeyUp", "SendQuery(this.value)")

        Dim dt As New DataTable

        If Not Page.IsPostBack Then

            dt = obj.GetInventoryTransferList(CompanyID, DivisionID, DepartmentID)

            If dt.Rows.Count > 0 Then
                InventoryTransferGrid.DataSource = dt
                InventoryTransferGrid.DataBind()
            End If

        End If

        If Not Page.IsPostBack Then
            txtDateFrom.Text = DateTime.Now.ToString("MM/dd/yyyy")
            txtDateTo.Text = DateTime.Now.ToString("MM/dd/yyyy")

        End If

    End Sub

    Protected Sub InventoryTransferGrid_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles InventoryTransferGrid.PageIndexChanging

        InventoryTransferGrid.PageIndex = e.NewPageIndex

        Dim dt As New DataTable

        dt = obj.GetInventoryTransferList(CompanyID, DivisionID, DepartmentID)

        If dt.Rows.Count > 0 Then
            InventoryTransferGrid.DataSource = dt
            InventoryTransferGrid.DataBind()
        End If

    End Sub




    Protected Sub InventoryTransferGrid_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles InventoryTransferGrid.RowCommand

        If e.CommandName = "MTPrint" Then
            Dim ordernumber As String
            ordernumber = e.CommandArgument

            'Response.Redirect("~/PO.aspx?CompanyID=" & CompanyID & "&DivisionID=" & DivisionID & "&DepartmentID=" & DepartmentID & "&EmployeeID=" & EmployeeID & "&PurchaseOrderNumber=" & ordernumber)

            Dim term As String = "" '= Session("TerminalID")

            Try
                term = Session("TerminalID")
            Catch ex As Exception

            End Try
            Dim constr11 As String = ConfigurationManager.AppSettings("ConnectionString")
            Dim connec As New SqlConnection(constr11)
            Dim qry As String
            qry = "insert into [MTSPrintRequest]( CompanyID, DivisionID, DepartmentID, [TerminalName]" _
            & " , [PrintText], [Active]) values(@f0,@f1,@f2,@f3,@f4,@f5)"
            Dim com As SqlCommand
            com = New SqlCommand(qry, connec)


            com.Parameters.Add(New SqlParameter("@f0", SqlDbType.NVarChar, 36)).Value = Me.CompanyID
            com.Parameters.Add(New SqlParameter("@f1", SqlDbType.NVarChar, 36)).Value = Me.DivisionID
            com.Parameters.Add(New SqlParameter("@f2", SqlDbType.NVarChar, 36)).Value = Me.DepartmentID
            com.Parameters.Add(New SqlParameter("@f3", SqlDbType.NVarChar, 36)).Value = term
            com.Parameters.Add(New SqlParameter("@f4", SqlDbType.NVarChar, 36)).Value = ordernumber
            com.Parameters.Add(New SqlParameter("@f5", SqlDbType.Bit)).Value = True
            Try
                com.Connection.Open()
                com.ExecuteNonQuery()
                com.Connection.Close()

            Catch ex As Exception
                Dim msg As String
                msg = ex.Message
                HttpContext.Current.Response.Write(msg)

            End Try

        End If


    End Sub



    'Protected Sub InventoryTransferGrid_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles InventoryTransferGrid.RowDeleting

    '    Dim TransferID As String = InventoryTransferGrid.DataKeys(e.RowIndex).Values(0).ToString()

    '    If obj.GetCountFutureDeliveryOrdersForTransferItem(CompanyID, DivisionID, DepartmentID, TransferID) = 0 Then
    '        obj.DeleteInventoryTransfer(CompanyID, DivisionID, DepartmentID, TransferID)
    '        Response.Redirect("NewInventoryTransferList.aspx")
    '    Else
    '        Dim objR As New Random
    '        Page.ClientScript.RegisterStartupScript(Me.GetType(), "OpenWindow" + Convert.ToString(objR.Next(1000)), _
    '                "alert('Orders for future delivery for this Transfer present. \n you can not delete this Transfer right now');", True)
    '    End If

    'End Sub

    Protected Sub InventoryTransferGrid_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles InventoryTransferGrid.RowEditing

        Dim TransferID As String = InventoryTransferGrid.DataKeys(e.NewEditIndex).Values(0).ToString()

        If TransferID <> "" Then
            Response.Redirect(String.Format("InventoryTransferDetaila.aspx?TransferNumber={0}", TransferID))
        End If

    End Sub

    Protected Sub InventoryTransferGrid_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles InventoryTransferGrid.Sorting

        Dim dt As New DataTable

        dt = obj.GetInventoryTransferList(CompanyID, DivisionID, DepartmentID)

        Dim dv As DataView = dt.DefaultView

        If hdSortDirection.Value = "" Or hdSortDirection.Value = "DESC" Then
            hdSortDirection.Value = "ASC"
        Else
            hdSortDirection.Value = "DESC"
        End If

        dv.Sort = e.SortExpression & " " & hdSortDirection.Value

        If dt.Rows.Count > 0 Then
            InventoryTransferGrid.DataSource = dv
            InventoryTransferGrid.DataBind()
        End If

    End Sub



    Protected Sub btncustsearch_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btncustsearch.Click
        Dim TempCustomerID As String = txtcustomersearch.Text
        lblsearchcustomermsg.ForeColor = Drawing.Color.Black

        If txtcustomersearch.Text.Trim = "" Then
            Exit Sub

        End If

        If TempCustomerID.IndexOf("[") > -1 Then
            Dim st, ed As Integer
            st = TempCustomerID.IndexOf("[")
            ed = TempCustomerID.IndexOf("]")

            If st = -1 Then
                Exit Sub
            End If

            If (ed - st) - 1 = -1 Then
                Exit Sub
            End If

            TempCustomerID = TempCustomerID.Substring(st + 1, (ed - st) - 1)
        End If


        txtcustomersearch.Text = TempCustomerID

        'BindOrderHeaderList()


        Dim dt As New DataTable

        dt = obj.GetInventoryTransferList(CompanyID, DivisionID, DepartmentID, TempCustomerID)

        If dt.Rows.Count > 0 Then
            InventoryTransferGrid.DataSource = dt
            InventoryTransferGrid.DataBind()
        End If

        txtcustomersearch.Text = "" '"dt.Rows.Count=" & dt.Rows.Count

    End Sub


    Protected Sub btnsearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnsearch.Click
        Dim dt As New DataTable


        If rdAllDates.Checked Then
            dt = GetInventoryTransferList(CompanyID, DivisionID, DepartmentID)

        ElseIf rdOrderDates.Checked Then
            dt = GetInventoryTransferListbyTransferDate(CompanyID, DivisionID, DepartmentID)

        ElseIf rdDeliveryDates.Checked Then

            dt = GetInventoryTransferListbyReceiveDate(CompanyID, DivisionID, DepartmentID)

        End If



        InventoryTransferGrid.DataSource = dt
        InventoryTransferGrid.DataBind()


    End Sub


    Public Function GetInventoryTransferList(ByVal CompanyID As String, ByVal DivisionID As String, ByVal DepartmentID As String, _
                                         Optional ByVal TransferNumber As String = "") As DataTable

        Dim dt As New DataTable

        Using Connection As New SqlConnection(ConfigurationManager.AppSettings("ConnectionString"))
            Using Command As New SqlCommand("[enterprise].[GetInventoryTransferList]", Connection)
                Command.CommandType = CommandType.StoredProcedure

                Command.Parameters.AddWithValue("CompanyID", CompanyID)
                Command.Parameters.AddWithValue("DivisionID", DivisionID)
                Command.Parameters.AddWithValue("DepartmentID", DepartmentID)
                Command.Parameters.AddWithValue("TransferNumber", TransferNumber)

                Try
                    Dim da As New SqlDataAdapter(Command)
                    da.Fill(dt)

                Catch ex As Exception

                End Try

            End Using
        End Using

        Return dt

    End Function


    Public Function GetInventoryTransferListbyTransferDate(ByVal CompanyID As String, ByVal DivisionID As String, ByVal DepartmentID As String, _
                                       Optional ByVal TransferNumber As String = "") As DataTable

        Dim dt As New DataTable

        Using Connection As New SqlConnection(ConfigurationManager.AppSettings("ConnectionString"))
            Using Command As New SqlCommand("[enterprise].[GetInventoryTransferListbyTransferDate]", Connection)
                Command.CommandType = CommandType.StoredProcedure

                Command.Parameters.AddWithValue("CompanyID", CompanyID)
                Command.Parameters.AddWithValue("DivisionID", DivisionID)
                Command.Parameters.AddWithValue("DepartmentID", DepartmentID)
                Command.Parameters.AddWithValue("TransferNumber", TransferNumber)
                Command.Parameters.AddWithValue("FromDate", txtDateFrom.Text)
                Command.Parameters.AddWithValue("ToDate", txtDateTo.Text)

                Try
                    Dim da As New SqlDataAdapter(Command)
                    da.Fill(dt)

                Catch ex As Exception

                End Try

            End Using
        End Using

        Return dt

    End Function

    Public Function GetInventoryTransferListbyReceiveDate(ByVal CompanyID As String, ByVal DivisionID As String, ByVal DepartmentID As String, _
                                       Optional ByVal TransferNumber As String = "") As DataTable

        Dim dt As New DataTable

        Using Connection As New SqlConnection(ConfigurationManager.AppSettings("ConnectionString"))
            Using Command As New SqlCommand("[enterprise].[GetInventoryTransferListbyReceiveDate]", Connection)
                Command.CommandType = CommandType.StoredProcedure

                Command.Parameters.AddWithValue("CompanyID", CompanyID)
                Command.Parameters.AddWithValue("DivisionID", DivisionID)
                Command.Parameters.AddWithValue("DepartmentID", DepartmentID)
                Command.Parameters.AddWithValue("TransferNumber", TransferNumber)
                Command.Parameters.AddWithValue("FromDate", txtDateFrom.Text)
                Command.Parameters.AddWithValue("ToDate", txtDateTo.Text)

                Dim da As New SqlDataAdapter(Command)
                da.Fill(dt)
                Try
                Catch ex As Exception

                End Try

            End Using
        End Using

        Return dt

    End Function




    Public Function totalprice(ByVal TransferNumber As String) As String
        Dim dtInventoryTransferDetail As New DataTable
        dtInventoryTransferDetail = InventoryTransferDetail(TransferNumber)


        If dtInventoryTransferDetail.Rows.Count > 0 Then

            Dim TransferQty As Integer = 0
            Dim MTPrice As Decimal = 0

            Try
                TransferQty = dtInventoryTransferDetail.Rows(0)(0)
            Catch ex As Exception

            End Try


            Try
                MTPrice = dtInventoryTransferDetail.Rows(0)(1)
            Catch ex As Exception

            End Try

            Return "$" & Format(MTPrice, "0.00")
        End If

        Return ""
    End Function



    Public Function InventoryTransferDetail(ByVal TransferNumber As String) As DataTable
        Dim dt As New DataTable
        Dim constr As String = ConfigurationManager.AppSettings("ConnectionString")
        Dim connec As New SqlConnection(constr)
        Dim qry As String
        qry = "select sum(InventoryTransferDetail.TransferQty) , sum(InventoryTransferDetail.TransferQty*InventoryTransferDetail.MTPrice)  from InventoryTransferDetail Where CompanyID=@f1  AND   DivisionID =@f2  AND  DepartmentID =@f3  AND [TransferNumber]=@f4"

        Dim com As SqlCommand
        com = New SqlCommand(qry, connec)
        Try
            com.Parameters.Add(New SqlParameter("@f1", SqlDbType.NVarChar, 36)).Value = Me.CompanyID.Trim()
            com.Parameters.Add(New SqlParameter("@f2", SqlDbType.NVarChar, 36)).Value = Me.DivisionID.Trim()
            com.Parameters.Add(New SqlParameter("@f3", SqlDbType.NVarChar, 36)).Value = Me.DepartmentID.Trim()
            com.Parameters.Add(New SqlParameter("@f4", SqlDbType.NVarChar, 36)).Value = TransferNumber

            com.CommandType = CommandType.Text

            Dim da As New SqlDataAdapter(com)

            da.Fill(dt)


            Return dt


        Catch ex As Exception
            Dim msg As String
            msg = ex.Message
            HttpContext.Current.Response.Write(msg)

        End Try
        Return dt
    End Function



End Class
