﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class ItemList
    Inherits System.Web.UI.Page

    Private obj As New clsItems

    Dim CompanyID As String = ""
    Dim DivisionID As String = ""
    Dim DepartmentID As String = ""
    Dim EmployeeID As String = ""

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

        Dim SessionKey As Hashtable = CType(Session("SessionKey"), Hashtable)
        CompanyID = CStr(SessionKey("CompanyID"))
        DivisionID = CStr(SessionKey("DivisionID"))
        DepartmentID = CStr(SessionKey("DepartmentID"))
        EmployeeID = CStr(SessionKey("EmployeeID"))

        obj.CompanyID = CompanyID
        obj.DivisionID = DivisionID
        obj.DepartmentID = DepartmentID

        fillHomePageManagement()
        If Not Page.IsPostBack Then
            GetInventoryItemsList()
        End If

    End Sub


    Public LeftMenuFooterText As String = ""

    Public Function fillHomePageManagement() As String
        Dim constr As String = ConfigurationManager.AppSettings("ConnectionString")
        Dim connec As New SqlConnection(constr)
        Dim ssql As String = ""
        Dim dt As New DataTable()
        ssql = "SELECT ConsultationRequestTitle,ConsultationRequestText,LeftMenuFooterText,MostPopular,SubscribeEmail,MenuFamilyGroupName,HomeLink1URL,HomeLink2URL,[HomeLink1],[HomeLink2] ,NewWebsitePhoneText ,NewWebsitePhoneNumber, FooterMessageHead ,FooterMessage , HomeSingleItemID,txtConentHeading,txtConentMessage,txtConentLinkName,txtConentLinkURL  FROM HomePageManagement where CompanyID=@f0 and DivisionID=@f1 and DepartmentID=@f2 "
        Dim da As New SqlDataAdapter
        Dim com As SqlCommand
        com = New SqlCommand(ssql, connec)
        Try
            com.Parameters.Add(New SqlParameter("@f0", SqlDbType.NVarChar, 36)).Value = Me.CompanyID
            com.Parameters.Add(New SqlParameter("@f1", SqlDbType.NVarChar, 36)).Value = Me.DivisionID
            com.Parameters.Add(New SqlParameter("@f2", SqlDbType.NVarChar, 36)).Value = Me.DepartmentID
            da.SelectCommand = com
            da.Fill(dt)


            If dt.Rows.Count > 0 Then
                Try
                    LeftMenuFooterText = dt.Rows(0)("LeftMenuFooterText")
                Catch ex As Exception

                End Try
                 


            End If

            Return ""
        Catch ex As Exception
            Dim msg As String
            msg = ex.Message
            HttpContext.Current.Response.Write(msg)
            Return ""
        End Try

    End Function



    Private Sub GetInventoryItemsList()

        Dim ds As New DataSet
        ds = obj.GetInventoryItemsList()

        If ds.Tables(0).Rows.Count > 0 Then
            gvItemsList.DataSource = ds
            gvItemsList.DataBind()
            lblInfo.Text = ds.Tables(0).Rows.Count.ToString + " records found"
        Else
            lblInfo.Text = "0 records found"
        End If

    End Sub

    Protected Sub gvItemsList_PageIndexChanging(sender As Object, e As GridViewPageEventArgs) Handles gvItemsList.PageIndexChanging

        gvItemsList.PageIndex = e.NewPageIndex
        GetInventoryItemsList()


    End Sub

    Protected Sub gvItemsList_Sorting(sender As Object, e As GridViewSortEventArgs) Handles gvItemsList.Sorting

        Dim ds As New DataSet

        ds = obj.GetInventoryItemsList()

        Dim dv As DataView = ds.Tables(0).DefaultView

        If gvSortDirection.Value = "" Or gvSortDirection.Value = "DESC" Then
            gvSortDirection.Value = "ASC"
        Else
            gvSortDirection.Value = "DESC"
        End If

        dv.Sort = e.SortExpression & " " & gvSortDirection.Value

        If ds.Tables(0).Rows.Count > 0 Then
            gvItemsList.DataSource = dv
            gvItemsList.DataBind()
        End If

    End Sub

    Protected Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click

        Dim ds As New DataSet

        If drpSearchFor.SelectedValue = "ItemID" Then
            ds = obj.GetInventoryItemsList(txtSearchValue.Text.Trim)
        ElseIf drpSearchFor.SelectedValue = "ItemName" Then
            ds = obj.GetInventoryItemsList(, txtSearchValue.Text.Trim)
        ElseIf drpSearchFor.SelectedValue = "ItemType" Then
            ds = obj.GetInventoryItemsList(, , txtSearchValue.Text.Trim)
        ElseIf drpSearchFor.SelectedValue = "Location" Then
            ds = obj.GetInventoryItemsList(, , , txtSearchValue.Text.Trim)
        ElseIf drpSearchFor.SelectedValue = "VendorID" Then
            ds = obj.GetInventoryItemsList(, , , , txtSearchValue.Text.Trim)
        End If

        gvItemsList.DataSource = ds
        gvItemsList.DataBind()

        If ds.Tables(0).Rows.Count > 0 Then
            lblInfo.Text = ds.Tables(0).Rows.Count.ToString + " records found"
        Else
            lblInfo.Text = "0 records found"
        End If

    End Sub

End Class
