﻿ 
Imports EnterpriseASPClient.Core
'Imports EnterpriseClient.Core
Imports System.Data
Imports System.Data.SqlClient

Partial Class EventInventoryAssemblyList
    Inherits System.Web.UI.Page

    Dim CompanyID As String = ""
    Dim DivisionID As String = ""
    Dim DepartmentID As String = ""

    Dim SortDirection As String

    Dim obj As New clsInventoryAssembly

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        'Dim SessionKey As Hashtable = CType(Session("SessionKey"), Hashtable)
        'CompanyID = CType(SessionKey("CompanyID"), String)
        'DivisionID = CType(SessionKey("DivisionID"), String)
        'DepartmentID = CType(SessionKey("DepartmentID"), String)

        CompanyID = Session("CompanyID")
        DivisionID = Session("DivisionID")
        DepartmentID = Session("DepartmentID")
        'EmployeeID = Session("EmployeeID")

        Dim dt As New DataTable

        If Not Page.IsPostBack Then

            dt = obj.GetInventoryAssmeblyList(CompanyID, DivisionID, DepartmentID)

            If dt.Rows.Count > 0 Then
                InventoryAssemblyGrid.DataSource = dt
                InventoryAssemblyGrid.DataBind()
            End If

        End If

    End Sub

    Protected Sub InventoryAssemblyGrid_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles InventoryAssemblyGrid.PageIndexChanging

        InventoryAssemblyGrid.PageIndex = e.NewPageIndex

        Dim dt As New DataTable

        dt = obj.GetInventoryAssmeblyList(CompanyID, DivisionID, DepartmentID)

        If dt.Rows.Count > 0 Then
            InventoryAssemblyGrid.DataSource = dt
            InventoryAssemblyGrid.DataBind()
        End If

    End Sub

    Protected Sub InventoryAssemblyGrid_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles InventoryAssemblyGrid.RowDeleting

        Dim AssemblyID As String = InventoryAssemblyGrid.DataKeys(e.RowIndex).Values(0).ToString()

        If obj.GetCountFutureDeliveryOrdersForAssemblyItem(CompanyID, DivisionID, DepartmentID, AssemblyID) = 0 Then
            obj.DeleteInventoryAssembly(CompanyID, DivisionID, DepartmentID, AssemblyID)
            Response.Redirect("EventInventoryAssemblyList.aspx")
        Else
            Dim objR As New Random
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "OpenWindow" + Convert.ToString(objR.Next(1000)), _
                    "alert('Orders for future delivery for this assembly present. \n you can not delete this assembly right now');", True)
        End If

    End Sub

    Protected Sub InventoryAssemblyGrid_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles InventoryAssemblyGrid.RowEditing

        Dim AssemblyID As String = InventoryAssemblyGrid.DataKeys(e.NewEditIndex).Values(0).ToString()

        If AssemblyID <> "" Then
            Response.Redirect(String.Format("RecipeDetails.aspx?AssemblyID={0}", AssemblyID))
        End If

    End Sub

    Protected Sub InventoryAssemblyGrid_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles InventoryAssemblyGrid.Sorting

        Dim dt As New DataTable

        dt = obj.GetInventoryAssmeblyList(CompanyID, DivisionID, DepartmentID)

        Dim dv As DataView = dt.DefaultView

        If hdSortDirection.Value = "" Or hdSortDirection.Value = "DESC" Then
            hdSortDirection.Value = "ASC"
        Else
            hdSortDirection.Value = "DESC"
        End If

        dv.Sort = e.SortExpression & " " & hdSortDirection.Value

        If dt.Rows.Count > 0 Then
            InventoryAssemblyGrid.DataSource = dv
            InventoryAssemblyGrid.DataBind()
        End If

    End Sub

End Class