﻿Imports System.Data.SqlClient

Imports System.Data
Imports DAL
Imports EnterpriseCommon.Configuration
Imports EnterpriseASPClient.Core
Imports EnterpriseClient.Core


Partial Class MainMaster
    Inherits System.Web.UI.MasterPage
    Public JsCompanyID As String = ""
    Public JSDivisionID As String = ""
    Public JSDepartmentID As String = ""
    Public JSUserName As String = ""

    Dim LastName As String
    Dim CompanyName As String
    Dim Email As String
    Dim Phone As String
    Dim StrSql As String

    Dim CompanyID As String = ""
    Dim DivisionID As String = ""
    Dim DepartmentID As String = ""
    Public EmployeeID As String = ""
    Public TerminalID As String = ""
    Public locationid As String = ""

    Public ShiftID As String = ""

    Public LoggOffURL As String = ""

    Public POURL As String = ""
    Public POURL2 As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        CompanyID = Session("CompanyID")
        DivisionID = Session("DivisionID")
        DepartmentID = Session("DepartmentID")
        EmployeeID = Session("EmployeeID")

        locationid = Session("Locationid")
        TerminalID = Session("TerminalID")

        JsCompanyID = CompanyID
        JSDivisionID = DivisionID
        JSDepartmentID = DepartmentID
        JSUserName = EmployeeID


        populateCompany()

        LoggOffURL = "QFPOSLogin.aspx?CompanyID=" & CompanyID & "&DivisionID=" & DivisionID & "&DepartmentID=" & DepartmentID & "&TerminalID=" & TerminalID & "&locationid=" & locationid & "&logoff=1"

        Dim dt As New DataTable
        Dim startdate As String = ""
        Dim endtdate As String = ""

        Try
            startdate = Request.QueryString("startdate")
            ' HttpContext.Current.Response.Write(startdate)
        Catch ex As Exception

        End Try
        Try
            endtdate = Request.QueryString("endDate")
            '  HttpContext.Current.Response.Write(endtdate)
        Catch ex As Exception

        End Try
        If startdate <> "" And endtdate <> "" Then
            '' InsertNewCartSession(startdate, endtdate)
        End If




        POURL = "http://bpombeta.quickflora.com/Web/BPO.aspx?CompanyID=" & CompanyID & "&DivisionID=" & DivisionID & "&DepartmentID=" & DepartmentID & "&TerminalID=" & "DEFAULT" & "&locationid=" & locationid & "&EmployeeID=" & EmployeeID & "&Session_SessionID=" & Session.SessionID
        POURL2 = "http://bpombeta.quickflora.com/Web/BPOR.aspx?CompanyID=" & CompanyID & "&DivisionID=" & DivisionID & "&DepartmentID=" & DepartmentID & "&TerminalID=" & "DEFAULT" & "&locationid=" & locationid & "&EmployeeID=" & EmployeeID & "&Session_SessionID=" & Session.SessionID

        Try
            ShiftID = "Shift ID: " & Session("ShiftID")
        Catch ex As Exception

        End Try



    End Sub


    Public Function InsertNewCartSession(ByVal startDate As String, ByVal endDate As String) As Boolean
        Dim ConnectionString As String = ""
        ConnectionString = ConfigurationManager.AppSettings("ConnectionString")
        Dim connec As New SqlConnection(ConnectionString)
        Dim qry As String
        qry = "INSERT INTO  [NewPOMSession] ([SessionBrowserID] ,[Employeeid] ,[CompanyID] ,[DivisionID] ,[DepartmentID] ,[startDate] ,[endDate]) "
        qry = qry & " values(@SessionID,@EmployeeID,@f1,@f2,@f3,@startDate,@endDate)"

        Dim com As SqlCommand
        com = New SqlCommand(qry, connec)
        Try
            com.Parameters.Add(New SqlParameter("@f1", SqlDbType.NVarChar, 36)).Value = Me.CompanyID
            com.Parameters.Add(New SqlParameter("@f2", SqlDbType.NVarChar, 36)).Value = Me.DivisionID
            com.Parameters.Add(New SqlParameter("@f3", SqlDbType.NVarChar, 36)).Value = Me.DepartmentID
            com.Parameters.Add(New SqlParameter("@EmployeeID", SqlDbType.NVarChar, 36)).Value = Me.EmployeeID
            com.Parameters.Add(New SqlParameter("@SessionID", SqlDbType.NVarChar)).Value = Session.SessionID
            com.Parameters.Add(New SqlParameter("@startDate", SqlDbType.NVarChar)).Value = startDate
            com.Parameters.Add(New SqlParameter("@endDate", SqlDbType.NVarChar)).Value = endDate

            com.Connection.Open()
            com.ExecuteNonQuery()
            com.Connection.Close()

            Return True

        Catch ex As Exception
            Dim msg As String
            msg = ex.Message
            HttpContext.Current.Response.Write(msg)
            Return False
        End Try

    End Function




    Dim constr As String = ConfigurationManager.AppSettings("ConnectionString")
    Dim ConnectionString As String = ""
    Dim reader As SqlDataReader

    Sub populateCompany()


        ConnectionString = ConfigurationManager.AppSettings("ConnectionString")
        Dim CommandText As String = "enterprise.spCompanyInformation"

        ' get the connection ready
        Dim myConnection As New SqlConnection(ConnectionString)
        Dim myCommand As New SqlCommand(CommandText, myConnection)
        Dim workParam As New SqlParameter()

        myCommand.CommandType = CommandType.StoredProcedure

        ' Set the input parameter, companyid, divisionid, departmentid
        ' these parameters are set in the sub page_load
        myCommand.Parameters.Add("@CompanyID", SqlDbType.NVarChar).Value = CompanyID
        myCommand.Parameters.Add("@DivisionID", SqlDbType.NVarChar).Value = DivisionID
        myCommand.Parameters.Add("@DepartmentID", SqlDbType.NVarChar).Value = DepartmentID


        ' open the connection
        myConnection.Open()
        reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection)

        While reader.Read()
            lblCompany.Text = reader(3).ToString()
            lblCompany.DataBind()
        End While
    End Sub

End Class

